import React, { useMemo, useState } from 'react';
import { View, StyleSheet, FlatList, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Text, Chip, Card } from '../components';
import { colors, radius } from '../theme';
import { useHistory, HistoryItem } from '../hooks/useHistory';

type Props = {
  onOpen: (item: HistoryItem) => void;
};

/**
 * Screen 3f — History list. Day-grouped cards with device tag + word count.
 */
export const HistoryListScreen: React.FC<Props> = ({ onOpen }) => {
  const insets = useSafeAreaInsets();
  const { items } = useHistory();
  const [filter, setFilter] = useState<'all' | string>('all');

  const filtered = useMemo(
    () => (filter === 'all' ? items : items.filter(i => i.deviceTag === filter)),
    [items, filter],
  );

  const grouped = useMemo(() => groupByDay(filtered), [filtered]);

  return (
    <View style={[styles.root, { paddingTop: insets.top + 10 }]}>
      <View style={styles.header}>
        <Text variant="titleSm">History</Text>
        <Pressable style={styles.iconBtn}>
          <Ionicons name="search" size={14} color={colors.textSecondary} />
        </Pressable>
      </View>

      <View style={styles.filters}>
        <Chip label="All" active={filter === 'all'} onPress={() => setFilter('all')} />
        <Chip label="MacBook" active={filter === 'MacBook'} onPress={() => setFilter('MacBook')} />
        <Chip label="Work PC" active={filter === 'Work PC'} onPress={() => setFilter('Work PC')} />
      </View>

      <FlatList
        data={grouped}
        keyExtractor={g => g.label}
        renderItem={({ item: group }) => (
          <View>
            <Text variant="meta" color={colors.textSubtle} style={{ marginBottom: 8, marginTop: 6 }}>
              {group.label}
            </Text>
            <View style={{ gap: 8, marginBottom: 14 }}>
              {group.items.map(item => (
                <Card key={item.id} padding={14} onPress={() => onOpen(item)}>
                  <View style={styles.cardHeader}>
                    <Text variant="metaSm" color={colors.textSubtle}>
                      {item.timeOfDay} · {item.deviceTag}
                    </Text>
                    <Text variant="metaSm" color={colors.primary}>
                      {item.wordCount}w
                    </Text>
                  </View>
                  <Text variant="bodySm" numberOfLines={2}>
                    {item.text}
                  </Text>
                </Card>
              ))}
            </View>
          </View>
        )}
        contentContainerStyle={{ paddingBottom: insets.bottom + 80 }}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

function groupByDay(items: HistoryItem[]) {
  const map = new Map<string, HistoryItem[]>();
  items.forEach(i => {
    const key = i.dayLabel ?? 'Earlier';
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(i);
  });
  return Array.from(map.entries()).map(([label, items]) => ({ label, items }));
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.bgScreen,
    paddingHorizontal: 18,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  iconBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.surface2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  filters: {
    flexDirection: 'row',
    gap: 6,
    marginBottom: 18,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
});

export default HistoryListScreen;
