import React from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Text, Chip, ChipDot, Card, MicButton, LogoMark } from '../components';
import { colors } from '../theme';
import { useDevices } from '../hooks/useDevices';
import { useHistory } from '../hooks/useHistory';
import { useAuth } from '../hooks/useAuth';

type Props = { onStartRecording: () => void };

/**
 * Screen 3c — Home / mic idle. First tab.
 * Last sent transcription card + thumb-zone mic.
 */
export const HomeScreen: React.FC<Props> = ({ onStartRecording }) => {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { devices, target, setTarget } = useDevices();
  const { items } = useHistory();
  const lastSent = items[0];

  return (
    <View style={[styles.root, { paddingTop: insets.top + 8 }]}>
      <View style={styles.header}>
        <View>
          <Text variant="caption" color={colors.textMuted}>Good morning</Text>
          <Text variant="subtitle">{user?.firstName ?? 'there'}</Text>
        </View>
        <LogoMark size={36} />
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ gap: 6, paddingRight: 16 }}
        style={{ marginBottom: 18, flexGrow: 0 }}
      >
        {devices
          .filter(d => d.status === 'online')
          .map(d => (
            <Chip
              key={d.id}
              label={d.name}
              active={d.id === target?.id}
              leading={d.id === target?.id ? <ChipDot /> : undefined}
              onPress={() => setTarget(d)}
            />
          ))}
      </ScrollView>

      {lastSent ? (
        <View style={{ marginBottom: 16 }}>
          <Text variant="meta" color={colors.textSubtle} style={{ marginBottom: 8 }}>LAST SENT</Text>
          <Card padding={14}>
            <Text variant="bodySm" style={{ marginBottom: 10 }}>
              "{lastSent.text}"
            </Text>
            <View style={styles.lastSentFooter}>
              <Text variant="metaSm" color={colors.textSubtle}>
                {lastSent.relativeTime} · {lastSent.durationLabel}
              </Text>
              <Text variant="button" color={colors.primary}>Resend</Text>
            </View>
          </Card>
        </View>
      ) : null}

      <View style={{ flex: 1 }} />

      <View style={[styles.micGroup, { paddingBottom: insets.bottom + 4 }]}>
        <Text variant="bodyXs" color={colors.textMuted}>Hold to speak</Text>
        <MicButton state="idle" onPress={onStartRecording} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.bgScreen,
    paddingHorizontal: 18,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 22,
  },
  lastSentFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  micGroup: {
    alignItems: 'center',
    gap: 12,
  },
});

export default HomeScreen;
