import React from 'react';
import { View, StyleSheet, Pressable, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Text, Card, Button } from '../components';
import { colors, radius } from '../theme';
import { HistoryItem } from '../hooks/useHistory';

type Props = {
  item: HistoryItem;
  onBack: () => void;
  onEdit: () => void;
  onCopy: () => void;
  onResend: () => void;
};

/**
 * Screen 3g — History detail. Audio playback bar + transcript + actions.
 */
export const HistoryDetailScreen: React.FC<Props> = ({
  item, onBack, onEdit, onCopy, onResend,
}) => {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.root, { paddingTop: insets.top + 10, paddingBottom: insets.bottom + 14 }]}>
      <View style={styles.topBar}>
        <Pressable onPress={onBack} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={18} color={colors.textSecondary} />
          <Text variant="buttonSm">History</Text>
        </Pressable>
        <Pressable style={styles.overflow}>
          <Ionicons name="ellipsis-horizontal" size={14} color={colors.textPrimary} />
        </Pressable>
      </View>

      <View style={{ marginBottom: 14 }}>
        <Text variant="meta" color={colors.textSubtle} style={{ marginBottom: 6 }}>
          {item.dayLabel} · {item.timeOfDay}
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <View style={styles.deviceIcon}>
            <Ionicons name="laptop-outline" size={11} color={colors.primary} />
          </View>
          <Text variant="button">{item.deviceTag}</Text>
          <Text variant="metaSm" color={colors.textSubtle}>
            · {item.durationLabel} · {item.wordCount} words
          </Text>
        </View>
      </View>

      <PlaybackBar />

      <Card padding={14} style={{ flex: 1, marginTop: 14 }}>
        <ScrollView>
          <Text variant="bodySm">{item.text}</Text>
        </ScrollView>
      </Card>

      <View style={styles.actionRow}>
        <Button label="Edit" variant="ghost" onPress={onEdit} style={{ flex: 1 }} />
        <Button label="Copy" variant="ghost" onPress={onCopy} style={{ flex: 1 }} />
        <Button label="Resend" onPress={onResend} style={{ flex: 1.3 }} />
      </View>
    </View>
  );
};

/** 20-line waveform with the first 5 colored = "played" position. */
const PlaybackBar: React.FC = () => {
  const heights = [6, 12, 18, 10, 20, 8, 14, 18, 6, 12, 16, 8, 14, 20, 8, 18, 10, 14, 6, 12];
  const playedTo = 5;
  return (
    <Card padding={12} style={{ paddingVertical: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <Pressable style={styles.playBtn}>
          <Ionicons name="play" size={11} color={colors.primaryInk} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <View style={styles.waveRow}>
            {heights.map((h, i) => (
              <View
                key={i}
                style={{
                  width: 2,
                  height: h,
                  borderRadius: 1,
                  backgroundColor: i < playedTo ? colors.primary : colors.textDisabled,
                }}
              />
            ))}
          </View>
          <View style={styles.timeRow}>
            <Text variant="metaSm" color={colors.textMuted}>0:04</Text>
            <Text variant="metaSm" color={colors.textMuted}>0:14</Text>
          </View>
        </View>
      </View>
    </Card>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.bgScreen,
    paddingHorizontal: 18,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  backBtn: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  overflow: {
    width: 28, height: 28, borderRadius: 8,
    backgroundColor: colors.surface2,
    alignItems: 'center', justifyContent: 'center',
  },
  deviceIcon: {
    width: 20, height: 20, borderRadius: 6,
    backgroundColor: colors.primarySoft,
    alignItems: 'center', justifyContent: 'center',
  },
  playBtn: {
    width: 30, height: 30, borderRadius: 15,
    backgroundColor: colors.primary,
    alignItems: 'center', justifyContent: 'center',
  },
  waveRow: { flexDirection: 'row', alignItems: 'center', gap: 2, height: 22 },
  timeRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 },
  actionRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 12,
  },
});

export default HistoryDetailScreen;
