import React from 'react';
import { View, StyleSheet, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Text, Button } from '../components';
import { colors, radius } from '../theme';

type Props = {
  onBack: () => void;
  onUseCode: () => void;
  /** Called with the scanned payload. Wire to your real camera/QR component. */
  onScan?: (payload: string) => void;
};

/**
 * Screen 3h — Pair a computer (QR scan).
 *
 * Note: This is the design shell. In production swap the viewfinder block
 * for the real <CameraView barcodeScannerSettings={{...}}> from expo-camera.
 */
export const PairDeviceScreen: React.FC<Props> = ({ onBack, onUseCode }) => {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.root, { paddingTop: insets.top + 10, paddingBottom: insets.bottom + 14 }]}>
      <View style={styles.topBar}>
        <Pressable onPress={onBack} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={18} color={colors.textSecondary} />
          <Text variant="button">Pair a computer</Text>
        </Pressable>
      </View>

      <Text variant="bodySm" color={colors.textSecondary} style={{ marginBottom: 18 }}>
        Open Flume on your computer and point your camera at the code shown.
      </Text>

      <View style={styles.viewfinder}>
        {/* TODO: replace with <CameraView ...> */}
        <View style={styles.frame} />
        <View style={[styles.corner, { top: 18, left: 18, borderTopLeftRadius: 12, borderTopWidth: 3, borderLeftWidth: 3 }]} />
        <View style={[styles.corner, { top: 18, right: 18, borderTopRightRadius: 12, borderTopWidth: 3, borderRightWidth: 3 }]} />
        <View style={[styles.corner, { bottom: 18, left: 18, borderBottomLeftRadius: 12, borderBottomWidth: 3, borderLeftWidth: 3 }]} />
        <View style={[styles.corner, { bottom: 18, right: 18, borderBottomRightRadius: 12, borderBottomWidth: 3, borderRightWidth: 3 }]} />
      </View>

      <Text variant="bodyXs" color={colors.textMuted} style={{ textAlign: 'center', marginBottom: 14 }}>
        No computer? <Text variant="bodyXs" color={colors.primary}>Get the app</Text>
      </Text>

      <View style={{ flex: 1 }} />

      <Button label="Enter code instead" variant="ghost" onPress={onUseCode} />
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.bgScreen,
    paddingHorizontal: 18,
  },
  topBar: { marginBottom: 20 },
  backBtn: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  viewfinder: {
    aspectRatio: 1,
    borderRadius: radius.xxl,
    backgroundColor: '#14110f',
    borderWidth: 1,
    borderColor: colors.borderSubtle,
    marginBottom: 18,
    overflow: 'hidden',
    position: 'relative',
  },
  frame: {
    position: 'absolute',
    top: 18, left: 18, right: 18, bottom: 18,
    borderWidth: 2,
    borderColor: colors.primary,
    borderRadius: 14,
  },
  corner: {
    position: 'absolute',
    width: 24, height: 24,
    borderColor: colors.primary,
  },
});

export default PairDeviceScreen;
