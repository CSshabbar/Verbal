import React, { useState, useMemo } from 'react';
import { View, StyleSheet, FlatList, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Text, Chip, Card } from '../components';
import { colors, radius, shadowFab } from '../theme';
import { useNotes, Note } from '../hooks/useNotes';

type Props = {
  onOpen: (note: Note) => void;
  onCreate: () => void;
};

/**
 * Screen 4a — Notes list. Filter by all/voice/typed, FAB to create.
 */
export const NotesListScreen: React.FC<Props> = ({ onOpen, onCreate }) => {
  const insets = useSafeAreaInsets();
  const { notes } = useNotes();
  const [filter, setFilter] = useState<'all' | 'voice' | 'typed'>('all');

  const filtered = useMemo(() => {
    if (filter === 'all') return notes;
    return notes.filter(n => (filter === 'voice' ? n.isVoice : !n.isVoice));
  }, [notes, filter]);

  return (
    <View style={[styles.root, { paddingTop: insets.top + 10 }]}>
      <View style={styles.header}>
        <Text variant="titleSm">Notes</Text>
        <Pressable style={styles.searchBtn}>
          <Ionicons name="search" size={14} color={colors.textSecondary} />
        </Pressable>
      </View>

      <View style={styles.filters}>
        <Chip label="All"   active={filter === 'all'}   onPress={() => setFilter('all')} />
        <Chip label="Voice" active={filter === 'voice'} onPress={() => setFilter('voice')} />
        <Chip label="Typed" active={filter === 'typed'} onPress={() => setFilter('typed')} />
      </View>

      <FlatList
        data={filtered}
        keyExtractor={n => n.id}
        renderItem={({ item }) => (
          <Card padding={14} onPress={() => onOpen(item)} style={{ marginBottom: 8 }}>
            <View style={styles.cardHeader}>
              <Text variant="button">{item.title}</Text>
              {item.isVoice ? (
                <Text variant="metaSm" color={colors.primary}>🎙 VOICE</Text>
              ) : null}
            </View>
            <Text variant="bodyXs" color={colors.textSecondary} numberOfLines={2} style={{ marginBottom: 8 }}>
              {item.preview}
            </Text>
            <Text variant="meta" color={colors.textSubtle}>{item.dateLabel}</Text>
          </Card>
        )}
        contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}
        showsVerticalScrollIndicator={false}
      />

      <Pressable
        onPress={onCreate}
        style={[styles.fab, shadowFab, { bottom: insets.bottom + 78 }]}
      >
        <Ionicons name="add" size={26} color={colors.primaryInk} />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.bgScreen,
    paddingHorizontal: 18,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  searchBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.surface2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  filters: { flexDirection: 'row', gap: 6, marginBottom: 18 },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  fab: {
    position: 'absolute',
    right: 18,
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default NotesListScreen;
