import { TextStyle } from 'react-native';

// Font family names match expo-google-fonts package exports.
// Install with:
//   npx expo install @expo-google-fonts/geist @expo-google-fonts/jetbrains-mono expo-font expo-splash-screen
//
// Then in App.tsx:
//   import { useFonts, Geist_400Regular, Geist_500Medium, Geist_600SemiBold, Geist_700Bold } from '@expo-google-fonts/geist';
//   import { JetBrainsMono_500Medium, JetBrainsMono_600SemiBold } from '@expo-google-fonts/jetbrains-mono';

export const fonts = {
  // Geist
  regular:  'Geist_400Regular',
  medium:   'Geist_500Medium',
  semibold: 'Geist_600SemiBold',
  bold:     'Geist_700Bold',
  // JetBrains Mono
  mono:        'JetBrainsMono_500Medium',
  monoBold:    'JetBrainsMono_600SemiBold',
} as const;

type Variant = Required<Pick<TextStyle,
  'fontFamily' | 'fontSize' | 'lineHeight'
>> & Pick<TextStyle,
  'letterSpacing' | 'textTransform'
>;

export const type: Record<string, Variant> = {
  // Display
  displayXL:     { fontFamily: fonts.bold,     fontSize: 44, lineHeight: 42,  letterSpacing: -1.3 },
  display:       { fontFamily: fonts.bold,     fontSize: 36, lineHeight: 36,  letterSpacing: -1.1 },
  displaySm:     { fontFamily: fonts.semibold, fontSize: 26, lineHeight: 29,  letterSpacing: -0.5 },
  title:         { fontFamily: fonts.semibold, fontSize: 22, lineHeight: 25 },
  titleSm:       { fontFamily: fonts.semibold, fontSize: 20, lineHeight: 24 },
  subtitle:      { fontFamily: fonts.semibold, fontSize: 18, lineHeight: 22 },
  bodyLg:        { fontFamily: fonts.medium,   fontSize: 14, lineHeight: 20 },
  body:          { fontFamily: fonts.regular,  fontSize: 13, lineHeight: 19 },
  bodySm:        { fontFamily: fonts.regular,  fontSize: 12.5, lineHeight: 19 },
  bodyXs:        { fontFamily: fonts.regular,  fontSize: 11.5, lineHeight: 16 },
  buttonPrimary: { fontFamily: fonts.semibold, fontSize: 13.5, lineHeight: 16 },
  button:        { fontFamily: fonts.semibold, fontSize: 13, lineHeight: 16 },
  buttonSm:      { fontFamily: fonts.medium,   fontSize: 12, lineHeight: 14 },
  label:         { fontFamily: fonts.medium,   fontSize: 11, lineHeight: 14 },
  caption:       { fontFamily: fonts.regular,  fontSize: 11, lineHeight: 14 },
  tabLabel:      { fontFamily: fonts.medium,   fontSize: 10, lineHeight: 12 },

  // Mono
  timer:         { fontFamily: fonts.monoBold, fontSize: 36, lineHeight: 38, letterSpacing: -0.7 },
  timerXL:       { fontFamily: fonts.mono,     fontSize: 56, lineHeight: 56, letterSpacing: -2.2 },
  code:          { fontFamily: fonts.mono,     fontSize: 20, lineHeight: 22 },
  meta:          { fontFamily: fonts.mono,     fontSize: 10, lineHeight: 12, letterSpacing: 1.4, textTransform: 'uppercase' },
  metaSm:        { fontFamily: fonts.mono,     fontSize: 9.5, lineHeight: 11, letterSpacing: 0.6, textTransform: 'uppercase' },

  // Brand wordmark — "FLUME"
  wordmark:      { fontFamily: fonts.semibold, fontSize: 13, lineHeight: 14, letterSpacing: 0.5 },
};

export type TypeVariant = keyof typeof type;
