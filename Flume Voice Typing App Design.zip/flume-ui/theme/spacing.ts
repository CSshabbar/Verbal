export const space = {
  px:   1,
  xs:   4,
  s:    8,
  m:    12,
  base: 16,
  l:    18,
  lg:   22,
  xl:   28,
  xxl:  36,
  xxxl: 48,
} as const;

export const radius = {
  xs:    6,
  sm:    8,
  md:    10,
  lg:    12,
  xl:    14,
  xxl:   18,
  pill:  999,
} as const;
