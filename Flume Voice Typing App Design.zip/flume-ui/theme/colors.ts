// Flume color tokens — dark theme.
// Every value here is lifted directly from the wireframes (3a–3i, 4a–4c).
// Light theme will live in a sibling file when designed.

export const colors = {
  // Surfaces
  bgCanvas:      '#14110f',
  bgScreen:      '#0b0908',
  surface1:      'rgba(245, 237, 228, 0.04)',
  surface2:      'rgba(245, 237, 228, 0.06)',
  surface3:      'rgba(245, 237, 228, 0.08)',
  scrim:         'rgba(0, 0, 0, 0.55)',

  // Lines
  borderSubtle:  'rgba(245, 237, 228, 0.06)',
  borderDefault: 'rgba(245, 237, 228, 0.08)',
  borderStrong:  'rgba(245, 237, 228, 0.12)',
  borderDashed:  'rgba(245, 237, 228, 0.16)',

  // Text
  textPrimary:   '#f5ede4',
  textSecondary: 'rgba(245, 237, 228, 0.65)',
  textMuted:     'rgba(245, 237, 228, 0.55)',
  textSubtle:    'rgba(245, 237, 228, 0.45)',
  textDisabled:  'rgba(245, 237, 228, 0.30)',

  // Brand (orange)
  primary:       '#E0552C',
  primaryInk:    '#14110f',
  primarySoft:   'rgba(224, 85, 44, 0.14)',
  primarySofter: 'rgba(224, 85, 44, 0.08)',
  primaryBorder: 'rgba(224, 85, 44, 0.35)',
  primaryDashed: 'rgba(224, 85, 44, 0.30)',
  primaryGlow:   'rgba(224, 85, 44, 0.35)',
  primaryAccent: '#ffb593',

  // Brand on light (Google / dictation highlight bg)
  inkLight:      '#f5ede4',

  // Status
  online:        '#4ad15a',
  recording:     '#E0552C',
  offline:       'rgba(245, 237, 228, 0.30)',
} as const;

export type ColorToken = keyof typeof colors;
