/**
 * useRecorder — audio capture + live transcription.
 * Wire `start` and `stop` to expo-av + your transcription API.
 *
 * For SDK 50+: import { Audio } from 'expo-av';
 *              await Audio.requestPermissionsAsync();
 *              const rec = new Audio.Recording();
 *              await rec.prepareToRecordAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
 *              await rec.startAsync();
 *              ...
 *              await rec.stopAndUnloadAsync();
 *              const uri = rec.getURI();
 */
import { useState, useRef, useEffect, useCallback } from 'react';

export type RecorderStatus = 'idle' | 'recording' | 'paused';

export type StopResult = {
  uri: string;
  durationMs: number;
  /** Final transcript (post-processed). Stream interim via `partialText`. */
  text: string;
};

export function useRecorder() {
  const [status, setStatus] = useState<RecorderStatus>('idle');
  const [durationMs, setDurationMs] = useState(0);
  const [partialText, setPartialText] = useState(''); // updates as transcription streams
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startedAtRef = useRef<number>(0);
  const accumulatedRef = useRef<number>(0);

  useEffect(() => () => {
    if (tickRef.current) clearInterval(tickRef.current);
  }, []);

  const start = useCallback(async () => {
    // TODO: await Audio.requestPermissionsAsync();
    // TODO: prepare and start native recording.
    // TODO: open WS / SSE stream to transcription service; setPartialText on each event.
    startedAtRef.current = Date.now();
    accumulatedRef.current = 0;
    setDurationMs(0);
    setStatus('recording');
    tickRef.current = setInterval(() => {
      setDurationMs(Date.now() - startedAtRef.current + accumulatedRef.current);
    }, 100);
  }, []);

  const pause = useCallback(async () => {
    // TODO: rec.pauseAsync();
    if (tickRef.current) clearInterval(tickRef.current);
    accumulatedRef.current += Date.now() - startedAtRef.current;
    setStatus('paused');
  }, []);

  const resume = useCallback(async () => {
    // TODO: rec.startAsync();
    startedAtRef.current = Date.now();
    tickRef.current = setInterval(() => {
      setDurationMs(Date.now() - startedAtRef.current + accumulatedRef.current);
    }, 100);
    setStatus('recording');
  }, []);

  const stop = useCallback(async (): Promise<StopResult | null> => {
    if (tickRef.current) clearInterval(tickRef.current);
    if (status === 'idle') return null;
    const total = status === 'paused'
      ? accumulatedRef.current
      : Date.now() - startedAtRef.current + accumulatedRef.current;
    setStatus('idle');
    setPartialText('');
    // TODO: const uri = await rec.stopAndUnloadAsync();
    // TODO: const text = await yourBackend.finalize(streamId);
    return { uri: '', durationMs: total, text: partialText };
  }, [status, partialText]);

  return {
    status,
    durationMs,
    partialText,
    uri: '', // populated post-stop
    start,
    pause,
    resume,
    stop,
  };
}
