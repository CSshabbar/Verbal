import { HistoryItem } from '../hooks/useHistory';
import { Note } from '../hooks/useNotes';

/** Root stack — auth + onboarding + the main app shell. */
export type RootStackParamList = {
  Welcome: undefined;
  Onboarding: undefined;
  Main: undefined;
  /** Modal — opened from anywhere. */
  Recording: undefined;
  Confirmation: {
    transcript: string;
    deviceName: string;
    durationSeconds: number;
    wordCount: number;
    transcribeMs: number;
  };
};

/** Bottom tabs. */
export type TabsParamList = {
  RecordTab:   undefined;
  NotesTab:    undefined;
  CanvasTab:   undefined;
  HistoryTab:  undefined;
  SettingsTab: undefined;
};

/** Stacks inside each tab. */
export type NotesStackParamList = {
  NotesList: undefined;
  NoteEditor: { noteId: string | null };
};

export type HistoryStackParamList = {
  HistoryList: undefined;
  HistoryDetail: { itemId: string };
};

export type SettingsStackParamList = {
  Settings: undefined;
  Devices: undefined;
  PairDevice: undefined;
};
