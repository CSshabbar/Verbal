import React from 'react';
import { NavigationContainer, Theme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import {
  WelcomeScreen,
  OnboardingScreen,
  HomeScreen,
  RecordingScreen,
  ConfirmationScreen,
  HistoryListScreen,
  HistoryDetailScreen,
  PairDeviceScreen,
  DevicesScreen,
  NotesListScreen,
  NoteEditorScreen,
  CanvasScreen,
} from '../screens';
import { colors, type } from '../theme';
import { useAuth } from '../hooks/useAuth';
import { useHistory } from '../hooks/useHistory';

import {
  RootStackParamList,
  TabsParamList,
  NotesStackParamList,
  HistoryStackParamList,
  SettingsStackParamList,
} from './types';

const flumeTheme: Theme = {
  dark: true,
  colors: {
    primary:      colors.primary,
    background:   colors.bgScreen,
    card:         colors.bgScreen,
    text:         colors.textPrimary,
    border:       colors.borderSubtle,
    notification: colors.primary,
  },
  fonts: undefined as any,
};

/* ────────────────────────────────────────────────────────────────
 * Sub-stacks
 * ──────────────────────────────────────────────────────────────── */

const NotesStack = createNativeStackNavigator<NotesStackParamList>();
function NotesNavigator() {
  return (
    <NotesStack.Navigator screenOptions={{ headerShown: false }}>
      <NotesStack.Screen name="NotesList">
        {({ navigation }) => (
          <NotesListScreen
            onCreate={() => navigation.navigate('NoteEditor', { noteId: null })}
            onOpen={(n) => navigation.navigate('NoteEditor', { noteId: n.id })}
          />
        )}
      </NotesStack.Screen>
      <NotesStack.Screen name="NoteEditor">
        {({ route, navigation }) => (
          <NoteEditorScreen
            noteId={route.params.noteId}
            onBack={() => navigation.goBack()}
          />
        )}
      </NotesStack.Screen>
    </NotesStack.Navigator>
  );
}

const HistoryStack = createNativeStackNavigator<HistoryStackParamList>();
function HistoryNavigator() {
  return (
    <HistoryStack.Navigator screenOptions={{ headerShown: false }}>
      <HistoryStack.Screen name="HistoryList">
        {({ navigation }) => (
          <HistoryListScreen
            onOpen={(item) => navigation.navigate('HistoryDetail', { itemId: item.id })}
          />
        )}
      </HistoryStack.Screen>
      <HistoryStack.Screen name="HistoryDetail">
        {({ route, navigation }) => <HistoryDetail itemId={route.params.itemId} onBack={() => navigation.goBack()} />}
      </HistoryStack.Screen>
    </HistoryStack.Navigator>
  );
}

const HistoryDetail: React.FC<{ itemId: string; onBack: () => void }> = ({ itemId, onBack }) => {
  const { items } = useHistory();
  const item = items.find(i => i.id === itemId);
  if (!item) return null;
  return (
    <HistoryDetailScreen
      item={item}
      onBack={onBack}
      onEdit={() => {/* TODO */}}
      onCopy={() => {/* TODO: Clipboard.setStringAsync(item.text) */}}
      onResend={() => {/* TODO: open device picker, then resend */}}
    />
  );
};

const SettingsStack = createNativeStackNavigator<SettingsStackParamList>();
function SettingsNavigator() {
  return (
    <SettingsStack.Navigator screenOptions={{ headerShown: false }}>
      <SettingsStack.Screen name="Settings">
        {({ navigation }) => (
          <SettingsPlaceholder
            onOpenDevices={() => navigation.navigate('Devices')}
          />
        )}
      </SettingsStack.Screen>
      <SettingsStack.Screen name="Devices">
        {({ navigation }) => (
          <DevicesScreen
            onBack={() => navigation.goBack()}
            onAddDevice={() => navigation.navigate('PairDevice')}
          />
        )}
      </SettingsStack.Screen>
      <SettingsStack.Screen name="PairDevice" options={{ presentation: 'modal' }}>
        {({ navigation }) => (
          <PairDeviceScreen
            onBack={() => navigation.goBack()}
            onUseCode={() => {/* TODO: code-entry screen */}}
          />
        )}
      </SettingsStack.Screen>
    </SettingsStack.Navigator>
  );
}

/** Tiny placeholder so the Settings tab compiles before real settings ship. */
const SettingsPlaceholder: React.FC<{ onOpenDevices: () => void }> = ({ onOpenDevices }) => {
  const insets = useSafeAreaInsets();
  const { Text: T } = require('../components/Text');
  const { Pressable, View } = require('react-native');
  return (
    <View style={{ flex: 1, backgroundColor: colors.bgScreen, paddingTop: insets.top + 12, paddingHorizontal: 18 }}>
      <T variant="titleSm" style={{ marginBottom: 18 }}>Settings</T>
      <Pressable
        onPress={onOpenDevices}
        style={{
          paddingVertical: 14, paddingHorizontal: 14,
          borderRadius: 12, borderWidth: 1,
          borderColor: colors.borderSubtle,
          backgroundColor: colors.surface1,
        }}
      >
        <T variant="button">Your devices</T>
      </Pressable>
    </View>
  );
};

/* ────────────────────────────────────────────────────────────────
 * Tabs
 * ──────────────────────────────────────────────────────────────── */

const Tabs = createBottomTabNavigator<TabsParamList>();
function TabsNavigator() {
  const insets = useSafeAreaInsets();
  return (
    <Tabs.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colors.bgScreen,
          borderTopColor: colors.borderSubtle,
          borderTopWidth: 1,
          height: 60 + insets.bottom,
          paddingTop: 10,
          paddingBottom: insets.bottom + 14,
        },
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textDisabled,
        tabBarLabelStyle: type.tabLabel,
      }}
    >
      <Tabs.Screen
        name="RecordTab"
        options={{
          title: 'Record',
          tabBarIcon: ({ color }) => <Ionicons name="mic-outline" size={20} color={color} />,
        }}
      >
        {({ navigation }) => (
          <HomeScreen onStartRecording={() => navigation.getParent()?.navigate('Recording' as never)} />
        )}
      </Tabs.Screen>
      <Tabs.Screen
        name="NotesTab"
        component={NotesNavigator}
        options={{
          title: 'Notes',
          tabBarIcon: ({ color }) => <Ionicons name="document-text-outline" size={20} color={color} />,
        }}
      />
      <Tabs.Screen
        name="CanvasTab"
        component={CanvasScreen}
        options={{
          title: 'Canvas',
          tabBarIcon: ({ color }) => <Ionicons name="grid-outline" size={20} color={color} />,
        }}
      />
      <Tabs.Screen
        name="HistoryTab"
        component={HistoryNavigator}
        options={{
          title: 'History',
          tabBarIcon: ({ color }) => <Ionicons name="time-outline" size={20} color={color} />,
        }}
      />
      <Tabs.Screen
        name="SettingsTab"
        component={SettingsNavigator}
        options={{
          title: 'Settings',
          tabBarIcon: ({ color }) => <Ionicons name="settings-outline" size={20} color={color} />,
        }}
      />
    </Tabs.Navigator>
  );
}

/* ────────────────────────────────────────────────────────────────
 * Root
 * ──────────────────────────────────────────────────────────────── */

const Root = createNativeStackNavigator<RootStackParamList>();

export const RootNavigator: React.FC = () => {
  const { user } = useAuth();
  const isSignedIn = !!user;

  return (
    <NavigationContainer theme={flumeTheme}>
      <StatusBar style="light" />
      <Root.Navigator screenOptions={{ headerShown: false }}>
        {!isSignedIn ? (
          <>
            <Root.Screen name="Welcome" component={WelcomeScreen} />
            <Root.Screen name="Onboarding">
              {({ navigation }) => (
                <OnboardingScreen
                  onDone={() => navigation.replace('Main')}
                  onSkip={() => navigation.replace('Main')}
                />
              )}
            </Root.Screen>
          </>
        ) : (
          <>
            <Root.Screen name="Main" component={TabsNavigator} />
            <Root.Screen
              name="Recording"
              options={{ presentation: 'modal', gestureEnabled: false }}
            >
              {({ navigation }) => (
                <RecordingScreen
                  onCancel={() => navigation.goBack()}
                  onComplete={(uri, durationMs) => {
                    navigation.replace('Confirmation', {
                      transcript: 'Your finished transcript appears here.',
                      deviceName: 'MacBook',
                      durationSeconds: Math.round(durationMs / 1000),
                      wordCount: 0,
                      transcribeMs: 1800,
                    });
                  }}
                />
              )}
            </Root.Screen>
            <Root.Screen
              name="Confirmation"
              options={{ presentation: 'modal', gestureEnabled: true }}
            >
              {({ route, navigation }) => (
                <ConfirmationScreen
                  {...route.params}
                  onDone={() => navigation.popToTop()}
                  onCopyAgain={() => {/* TODO */}}
                  onEditInHistory={() => {/* TODO: pop to top + navigate History tab */}}
                  onResendToAnother={() => {/* TODO: device picker */}}
                />
              )}
            </Root.Screen>
          </>
        )}
      </Root.Navigator>
    </NavigationContainer>
  );
};

export default RootNavigator;
